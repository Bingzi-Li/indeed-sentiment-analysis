import {
    successColor,
    whiteColor,
    grayColor,
    hexToRgb
} from "assets/jss/material-dashboard-react.js";

const searchStyle = {
    searchBox: {
        height: "442px",
        backgroundColor: "#4281ea",
        display: "flex",
        flexFlow: "column",
        justifyContent: "center",
    },
    exampleBox: {
        position: "relative",
        top: "-80px"


    }

};

export default searchStyle;
